#!/usr/bin/env bash
set -euo pipefail

# variáveis comuns
RG="rg-elysia"
LOC="brazilsouth"

PLAN="plan-elysia"
APP="elysia-api"
RUNTIME="DOTNETCORE|8.0"

APP_INSIGHTS_NAME="ai-elysia"

PG_SERVER="elysiapg"
PG_DB="elysia_devops"
PG_ADMIN="pgadmin"
PG_ADMIN_PWD='Elysia@admin25'
PG_APP_USER="elysia_app"
PG_APP_PWD='Elysia@app25'
PG_HOST="${PG_SERVER}.postgres.database.azure.com"

# criando application insights
az monitor app-insights component create \
  --app "$APP_INSIGHTS_NAME" \
  --location "$LOC" \
  --resource-group "$RG" \
  --application-type web

# obtendo connectionString do insights
CONNECTION_STRING=$(az monitor app-insights component show \
  --app "$APP_INSIGHTS_NAME" \
  --resource-group "$RG" \
  --query connectionString -o tsv)

# configurando app settings no web app
az webapp config appsettings set \
  --name "$APP" \
  --resource-group "$RG" \
  --settings \
  APPLICATIONINSIGHTS_CONNECTION_STRING="$CONNECTION_STRING" \
  ApplicationInsightsAgent_EXTENSION_VERSION="~3" \
  XDT_MicrosoftApplicationInsights_Mode="Recommended" \
  XDT_MicrosoftApplicationInsights_PreemptSdk="1"

# conectando insights ao web app
az monitor app-insights component connect-webapp \
  --app "$APP_INSIGHTS_NAME" \
  --web-app "$APP" \
  --resource-group "$RG"

# reiniciando web app
az webapp restart --name "$APP" --resource-group "$RG"

# application Insights configurado

