#!/usr/bin/env bash
set -euo pipefail

# variáveis 
RG="rg-elysia"
LOC="brazilsouth"

PLAN="plan-elysia"
APP="elysia-api"
RUNTIME="DOTNETCORE|8.0"

APP_INSIGHTS_NAME="ai-elysia"

PG_SERVER="elysiapg"
PG_DB="elysia_devops"
PG_ADMIN="pgadmin"
PG_ADMIN_PWD='Elysia@admin25'
PG_APP_USER="elysia_app"
PG_APP_PWD='Elysia@app25'
PG_HOST="${PG_SERVER}.postgres.database.azure.com"

# criando resource Group 
az group create --name "$RG" --location "$LOC" >/dev/null

# criando postgres flexible-server
az postgres flexible-server create \
  --resource-group "$RG" \
  --name "$PG_SERVER" \
  --location "$LOC" \
  --admin-user "$PG_ADMIN" \
  --admin-password "$PG_ADMIN_PWD" \
  --public-access 0.0.0.0 \
  --version 16 \
  --tier Burstable \
  --sku-name Standard_B1ms \
  --storage-size 32

# criando database lógico
az postgres flexible-server db create \
  --resource-group "$RG" \
  --server-name "$PG_SERVER" \
  --database-name "$PG_DB"

# criando usuário da aplicação e concedendo permissões
cat > create_app_user.sql <<SQL
DO \$\$ BEGIN
   IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '${PG_APP_USER}') THEN
      CREATE ROLE ${PG_APP_USER} LOGIN PASSWORD '${PG_APP_PWD}';
   END IF;
END \$\$;

GRANT CONNECT ON DATABASE ${PG_DB} TO ${PG_APP_USER};
GRANT USAGE ON SCHEMA public TO ${PG_APP_USER};
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO ${PG_APP_USER};
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO ${PG_APP_USER};
SQL

# criando DDL + inserts 
cat > script_bd.sql <<'SQL'
CREATE TABLE IF NOT EXISTS "MotoCsharp" (
    "Id"      INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "Placa"   VARCHAR(8)  NOT NULL,
    "Marca"   VARCHAR(50) NOT NULL,
    "Modelo"  VARCHAR(50) NOT NULL,
    "Ano"     INTEGER     NOT NULL
);

CREATE TABLE IF NOT EXISTS "UsuarioCsharp" (
    "Id"     INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "Nome"   VARCHAR(80)  NOT NULL,
    "Email"  VARCHAR(254) NOT NULL,
    "Senha"  VARCHAR(120) NOT NULL,
    "Cpf"    VARCHAR(11)  NOT NULL
);

CREATE TABLE IF NOT EXISTS "VagaCsharp" (
    "Id"     INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "Status" VARCHAR(20)  NULL,
    "Numero" INTEGER      NOT NULL,
    "Patio"  VARCHAR(50)  NOT NULL
);

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'uk_usuariocsharp_email') THEN
        CREATE UNIQUE INDEX uk_usuariocsharp_email ON "UsuarioCsharp"("Email");
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'uk_usuariocsharp_cpf') THEN
        CREATE UNIQUE INDEX uk_usuariocsharp_cpf   ON "UsuarioCsharp"("Cpf");
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'uk_vaga_patio_numero') THEN
        CREATE UNIQUE INDEX uk_vaga_patio_numero   ON "VagaCsharp"("Patio","Numero");
    END IF;
END $$;

INSERT INTO "VagaCsharp"("Status","Numero","Patio") VALUES ('Livre',  1, 'Mottu Vila Mariana');
INSERT INTO "VagaCsharp"("Status","Numero","Patio") VALUES ('Ocupada',  2, 'Mottu Vila Mariana');
SQL

# aplicando scripts no servidor 
PGPASSWORD="$PG_ADMIN_PWD" psql "host=$PG_HOST port=5432 dbname=$PG_DB user=$PG_ADMIN sslmode=require" -f create_app_user.sql
PGPASSWORD="$PG_ADMIN_PWD" psql "host=$PG_HOST port=5432 dbname=$PG_DB user=$PG_ADMIN sslmode=require" -f script_bd.sql

# arquivo .env.elysia com a connection string
PG_CONN="Host=$PG_HOST;Port=5432;Database=$PG_DB;Username=$PG_APP_USER;Password=$PG_APP_PWD;Ssl Mode=Require;"

echo "PG_CONN=\"$PG_CONN\"" > .env.elysia
echo "connection String salva em ./.env.elysia"