#!/usr/bin/env bash
set -euo pipefail

# variáveis
RG="rg-elysia"
LOC="brazilsouth"

PLAN="plan-elysia"
APP="elysia-api"
RUNTIME="DOTNETCORE|8.0"

APP_INSIGHTS_NAME="ai-elysia"

PG_SERVER="elysiapg"
PG_DB="elysia_devops"
PG_ADMIN="pgadmin"
PG_ADMIN_PWD='Elysia@admin25'
PG_APP_USER="elysia_app"
PG_APP_PWD='Elysia@app25'
PG_HOST="${PG_SERVER}.postgres.database.azure.com"

# criando app service plan
az appservice plan create \
  --name "$PLAN" \
  --resource-group "$RG" \
  --location "$LOC" \
  --sku B1 \
  --is-linux


# criando web app (.NET 8)
az webapp create \
  --resource-group "$RG" \
  --plan "$PLAN" \
  --name "$APP" \
  --runtime "$RUNTIME"

# lendo/montando connection string do arquivo .env.elysia 
if [ -f .env.elysia ]; then
  source .env.elysia
else
  PG_CONN="Host=$PG_HOST;Port=5432;Database=$PG_DB;Username=$PG_APP_USER;Password=$PG_APP_PWD;Ssl Mode=Require;"
fi

# configurando ConnectionStrings:PostgresDB no Web App
az webapp config connection-string set \
  --resource-group "$RG" \
  --name "$APP" \
  --settings PostgresDB="$PG_CONN" \
  --connection-string-type PostgreSQL


# faça upload do publish.zip e rode:
az webapp deploy \
  --resource-group "$RG" \
  --name "$APP" \
  --src-path ./publish.zip \
  --type zip