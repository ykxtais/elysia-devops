CREATE TABLE IF NOT EXISTS "MotoCsharp" (
    "Id"      INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "Placa"   VARCHAR(8)  NOT NULL,
    "Marca"   VARCHAR(50) NOT NULL,
    "Modelo"  VARCHAR(50) NOT NULL,
    "Ano"     INTEGER     NOT NULL
);

CREATE TABLE IF NOT EXISTS "UsuarioCsharp" (
    "Id"     INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "Nome"   VARCHAR(80)  NOT NULL,
    "Email"  VARCHAR(254) NOT NULL,
    "Senha"  VARCHAR(120) NOT NULL,
    "Cpf"    VARCHAR(11)  NOT NULL
);

CREATE TABLE IF NOT EXISTS "VagaCsharp" (
    "Id"     INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "Status" VARCHAR(20)  NULL,
    "Numero" INTEGER      NOT NULL,
    "Patio"  VARCHAR(50)  NOT NULL
);

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'uk_usuariocsharp_email') THEN
        CREATE UNIQUE INDEX uk_usuariocsharp_email ON "UsuarioCsharp"("Email");
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'uk_usuariocsharp_cpf') THEN
        CREATE UNIQUE INDEX uk_usuariocsharp_cpf   ON "UsuarioCsharp"("Cpf");
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'uk_vaga_patio_numero') THEN
        CREATE UNIQUE INDEX uk_vaga_patio_numero   ON "VagaCsharp"("Patio","Numero");
    END IF;
END $$;

INSERT INTO "VagaCsharp"("Status","Numero","Patio") VALUES ('Livre',  1, 'Mottu Vila Mariana');
INSERT INTO "VagaCsharp"("Status","Numero","Patio") VALUES ('Ocupada',  2, 'Mottu Vila Mariana');

